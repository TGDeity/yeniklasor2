import React from 'react';
import Dashboard from './components/Dashboard';
import ConfigPanel from './components/ConfigPanel';
import ActiveTasks from './components/ActiveTasks';
import VideoStatus from './components/VideoStatus';
import StorageInfo from './components/StorageInfo';
import PerformanceMetrics from './components/PerformanceMetrics';
import ManualCleanup from './components/ManualCleanup';
import './App.css';

export default function App() {
  return (
    <div style={{ maxWidth: 900, margin: '40px auto', padding: 24 }}>
      <h2>Node.js Admin Panel (React)</h2>
      <Dashboard />
      <ConfigPanel />
      <ActiveTasks />
      <VideoStatus />
      <StorageInfo />
      <PerformanceMetrics />
      <ManualCleanup />
    </div>
  );
} 