import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8082/api/v1';

export default function Dashboard() {
  const [resources, setResources] = useState(null);
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    Promise.all([
      axios.get(`${API_URL}/status/system/resources`),
      axios.get(`${API_URL}/status/system/health`)
    ])
      .then(([res1, res2]) => {
        setResources(res1.data);
        setHealth(res2.data);
        setLoading(false);
      })
      .catch(() => {
        setError('API bağlantı hatası');
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Yükleniyor...</div>;
  if (error) return <div style={{ color: 'red' }}>{error}</div>;

  return (
    <div className="row mb-4">
      <div className="col-12">
        <div className="card mb-3">
          <div className="card-header"><b>Sistem Kaynakları</b></div>
          <div className="card-body row">
            <div className="col-md-3"><b>CPU:</b> {resources.cpu_percent}% ({resources.cpu_cores} çekirdek)</div>
            <div className="col-md-3"><b>RAM:</b> {resources.memory_used_gb}/{resources.memory_total_gb} GB ({resources.memory_percent}%)</div>
            <div className="col-md-3"><b>Disk:</b> {resources.disk_free_gb}/{resources.disk_total_gb} GB ({resources.disk_percent}%)</div>
            <div className="col-md-3"><b>GPU:</b> {resources.gpu && resources.gpu.available ? `${resources.gpu.gpus.length} GPU` : 'Yok'}</div>
          </div>
        </div>
        <div className="card mb-3">
          <div className="card-header"><b>Servis Durumu</b></div>
          <div className="card-body row">
            {health && health.services && Object.entries(health.services).map(([name, svc]) => (
              <div className="col-md-4" key={name}>
                <b>{name.toUpperCase()}:</b> <span style={{ color: svc.status === 'healthy' ? 'green' : svc.status === 'degraded' ? 'orange' : 'red' }}>{svc.status}</span>
                {svc.details && <div style={{ fontSize: 12 }}>{svc.details}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
} 