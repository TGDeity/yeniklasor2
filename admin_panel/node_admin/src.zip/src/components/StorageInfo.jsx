import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8082/api/v1';

export default function StorageInfo() {
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchInfo = () => {
    setLoading(true);
    axios.get(`${API_URL}/status/system/storage`)
      .then(res => {
        setInfo(res.data);
        setLoading(false);
      })
      .catch(() => {
        setError('API bağlantı hatası');
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchInfo();
    const interval = setInterval(fetchInfo, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="card mb-3">
      <div className="card-header"><b>Depolama Bilgisi</b></div>
      <div className="card-body">
        {loading ? <div>Yükleniyor...</div> : error ? <div style={{ color: 'red' }}>{error}</div> : (
          <div className="row">
            {Object.entries(info).map(([dir, data]) => (
              <div className="col-md-3 mb-3" key={dir}>
                <div className="card resource-card">
                  <div className="card-body text-center">
                    <b>{dir}</b><br />
                    <span>{data.size_mb} MB</span><br />
                    <small>{data.file_count} dosya</small><br />
                    {!data.exists && <span className="badge bg-warning">Yok</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
} 