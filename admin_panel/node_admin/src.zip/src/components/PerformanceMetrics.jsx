import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8082/api/v1';

export default function PerformanceMetrics() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchMetrics = () => {
    setLoading(true);
    axios.get(`${API_URL}/status/system/performance`)
      .then(res => {
        setMetrics(res.data);
        setLoading(false);
      })
      .catch(() => {
        setError('API bağlantı hatası');
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="card mb-3">
      <div className="card-header"><b>Performans Metrikleri</b></div>
      <div className="card-body">
        {loading ? <div>Yükleniyor...</div> : error ? <div style={{ color: 'red' }}>{error}</div> : (
          <div className="row">
            <div className="col-md-3 system-metric">
              <div className="metric-value text-primary">{metrics.upload_count || 0}</div>
              <div className="metric-label">Uploads</div>
            </div>
            <div className="col-md-3 system-metric">
              <div className="metric-value text-info">{metrics.processing_count || 0}</div>
              <div className="metric-label">Processing</div>
            </div>
            <div className="col-md-3 system-metric">
              <div className="metric-value text-success">{metrics.success_count || 0}</div>
              <div className="metric-label">Success</div>
            </div>
            <div className="col-md-3 system-metric">
              <div className="metric-value text-danger">{metrics.error_count || 0}</div>
              <div className="metric-label">Errors</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
} 