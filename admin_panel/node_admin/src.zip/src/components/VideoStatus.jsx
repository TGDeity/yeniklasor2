import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8082/api/v1';

export default function VideoStatus() {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchVideos = () => {
    setLoading(true);
    axios.get(`${API_URL}/status/videos`)
      .then(res => {
        setVideos(res.data.videos || []);
        setLoading(false);
      })
      .catch(() => {
        setError('API bağlantı hatası');
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchVideos();
    const interval = setInterval(fetchVideos, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="card mb-3">
      <div className="card-header"><b>Video İşleme Durumu</b></div>
      <div className="card-body">
        {loading ? <div>Yükleniyor...</div> : error ? <div style={{ color: 'red' }}>{error}</div> : (
          videos.length === 0 ? <div>Video bulunamadı</div> : (
            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Video ID</th>
                    <th>Durum</th>
                    <th>İlerleme</th>
                    <th>Güncellendi</th>
                    <th>Aksiyon</th>
                  </tr>
                </thead>
                <tbody>
                  {videos.map(video => (
                    <tr key={video.video_id}>
                      <td><code>{video.video_id.slice(0, 8)}...</code></td>
                      <td>
                        <span className={
                          video.status === 'completed' ? 'badge bg-success' :
                          video.status === 'processing' ? 'badge bg-warning' :
                          video.status === 'failed' ? 'badge bg-danger' : 'badge bg-secondary'
                        }>
                          {video.status || 'unknown'}
                        </span>
                      </td>
                      <td>
                        {video.progress ? (
                          <div className="progress" style={{ height: 20 }}>
                            <div className="progress-bar" style={{ width: `${video.progress}%` }}>{video.progress}%</div>
                          </div>
                        ) : <span className="text-muted">-</span>}
                      </td>
                      <td>{video.modified}</td>
                      <td>
                        {video.status === 'completed' && (
                          <a href={`${API_URL}/status/download/${video.video_id}`} className="btn btn-sm btn-success" target="_blank" rel="noopener noreferrer">
                            İndir
                          </a>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}
      </div>
    </div>
  );
} 