import React, { useState } from 'react';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8082/api/v1';

export default function ManualCleanup() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const triggerCleanup = async () => {
    if (!window.confirm('Manuel temizlik başlatılsın mı?')) return;
    setLoading(true);
    setSuccess('');
    setError('');
    try {
      const res = await axios.post(`${API_URL}/system/cleanup`);
      setSuccess(res.data.message || 'Temizlik başlatıldı!');
    } catch (err) {
      setError('Temizlik hatası');
    }
    setLoading(false);
  };

  return (
    <div className="card mb-3">
      <div className="card-header"><b>Manuel Temizlik</b></div>
      <div className="card-body text-center">
        <button className="btn btn-primary" onClick={triggerCleanup} disabled={loading}>
          {loading ? 'Çalışıyor...' : 'Temizliği Başlat'}
        </button>
        {success && <div style={{ color: 'green', marginTop: 8 }}>{success}</div>}
        {error && <div style={{ color: 'red', marginTop: 8 }}>{error}</div>}
      </div>
    </div>
  );
} 