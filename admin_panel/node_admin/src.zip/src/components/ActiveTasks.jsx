import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8082/api/v1';

export default function ActiveTasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [canceling, setCanceling] = useState('');
  const [success, setSuccess] = useState('');

  const fetchTasks = () => {
    setLoading(true);
    axios.get(`${API_URL}/status/tasks/active`)
      .then(res => {
        setTasks(res.data.active_tasks || []);
        setLoading(false);
      })
      .catch(() => {
        setError('API bağlantı hatası');
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchTasks();
    const interval = setInterval(fetchTasks, 30000);
    return () => clearInterval(interval);
  }, []);

  const cancelTask = async (taskId) => {
    if (!window.confirm('Bu görevi iptal etmek istediğinize emin misiniz?')) return;
    setCanceling(taskId);
    setError('');
    setSuccess('');
    try {
      await axios.delete(`${API_URL}/status/tasks/${taskId}`);
      setSuccess('Görev iptal edildi!');
      fetchTasks();
    } catch (err) {
      setError('İptal hatası');
    }
    setCanceling('');
  };

  return (
    <div className="card mb-3">
      <div className="card-header"><b>Aktif Görevler</b></div>
      <div className="card-body">
        {loading ? <div>Yükleniyor...</div> : error ? <div style={{ color: 'red' }}>{error}</div> : (
          tasks.length === 0 ? <div>Aktif görev yok</div> : (
            <div className="table-responsive">
              <table className="table table-sm">
                <thead>
                  <tr>
                    <th>Task ID</th>
                    <th>İsim</th>
                    <th>Worker</th>
                    <th>Başlangıç</th>
                    <th>Aksiyon</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map(task => (
                    <tr key={task.task_id}>
                      <td><code>{task.task_id.slice(0, 8)}...</code></td>
                      <td>{task.name}</td>
                      <td>{task.worker}</td>
                      <td>{task.time_start || 'Bilinmiyor'}</td>
                      <td>
                        <button className="btn btn-sm btn-danger" disabled={canceling === task.task_id} onClick={() => cancelTask(task.task_id)}>
                          {canceling === task.task_id ? 'İptal...' : 'İptal Et'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}
        {success && <div style={{ color: 'green' }}>{success}</div>}
      </div>
    </div>
  );
} 