import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8082/api/v1';

function Section({ title, children }) {
  return (
    <div className="card mb-3">
      <div className="card-header"><b>{title}</b></div>
      <div className="card-body">{children}</div>
    </div>
  );
}

export default function ConfigPanel() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = () => {
    setLoading(true);
    axios.get(`${API_URL}/config`)
      .then(res => {
        setConfig(res.data);
        setLoading(false);
      })
      .catch(() => {
        setError('API bağlantı hatası');
        setLoading(false);
      });
  };

  const handleUpdate = async (setting_path, value) => {
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      await axios.post(`${API_URL}/config/update`, { setting_path, value });
      setSuccess('Başarıyla güncellendi!');
      fetchConfig();
    } catch (err) {
      setError('Güncelleme hatası');
    }
    setSaving(false);
  };

  if (loading) return <div>Yükleniyor...</div>;
  if (error) return <div style={{ color: 'red' }}>{error}</div>;
  if (!config) return null;

  return (
    <div>
      <Section title="Timeout Ayarları (saniye)">
        {Object.entries(config.timeouts).map(([key, value]) => (
          <div key={key} style={{ marginBottom: 16 }}>
            <label>{key}: {value}</label>
            <input type="range" min={60} max={3600} value={value} disabled={saving}
              onChange={e => handleUpdate(`timeouts.${key}`, parseInt(e.target.value, 10))} />
          </div>
        ))}
      </Section>
      <Section title="Kaynak Limitleri">
        {Object.entries(config.resources).map(([key, value]) => (
          <div key={key} style={{ marginBottom: 16 }}>
            <label>{key}: {value}</label>
            <input type="range"
              min={key.includes('mb') ? 100 : key.includes('gb') ? 1 : 1}
              max={key.includes('mb') ? 2000 : key.includes('gb') ? 16 : 8}
              value={value} disabled={saving}
              onChange={e => handleUpdate(`resources.${key}`, parseInt(e.target.value, 10))} />
          </div>
        ))}
      </Section>
      <Section title="Performans Ayarları">
        {Object.entries(config.performance).map(([key, value]) => (
          <div key={key} className="form-check form-switch mb-2">
            <input className="form-check-input" type="checkbox" id={key} checked={!!value} disabled={saving}
              onChange={e => handleUpdate(`performance.${key}`, e.target.checked)} />
            <label className="form-check-label" htmlFor={key}>{key}</label>
          </div>
        ))}
      </Section>
      <Section title="Temizlik Ayarları">
        {Object.entries(config.cleanup).map(([key, value]) => (
          <div key={key} style={{ marginBottom: 16 }}>
            {key === 'auto_cleanup_temp_files' ? (
              <div className="form-check form-switch">
                <input className="form-check-input" type="checkbox" id={key} checked={!!value} disabled={saving}
                  onChange={e => handleUpdate(`cleanup.${key}`, e.target.checked)} />
                <label className="form-check-label" htmlFor={key}>{key}</label>
              </div>
            ) : (
              <>
                <label>{key}: {value}</label>
                <input type="range" min={300} max={86400} value={value} disabled={saving}
                  onChange={e => handleUpdate(`cleanup.${key}`, parseInt(e.target.value, 10))} />
              </>
            )}
          </div>
        ))}
      </Section>
      {saving && <div>Kaydediliyor...</div>}
      {success && <div style={{ color: 'green' }}>{success}</div>}
      {error && <div style={{ color: 'red' }}>{error}</div>}
    </div>
  );
} 